using Pkg
Pkg.add("Distributions")
