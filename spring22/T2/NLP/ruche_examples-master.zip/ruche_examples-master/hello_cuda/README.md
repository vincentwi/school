# Sample cuda job

To launch this example

```shell
sbatch slurm.sh
```