# Sample bash job using a slurm array

To launch this example.

```shell
sbatch slurm.sh
```
