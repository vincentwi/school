# Sample bash job

To launch this example.

```shell
sbatch slurm.sh
```
