srun --nodes=1 --time=01:00:00 --gres=gpu:1  -p gpu --pty /bin/bash
