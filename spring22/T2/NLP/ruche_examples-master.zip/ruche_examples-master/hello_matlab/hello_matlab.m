LASTN = maxNumCompThreads(2)
a = rand(20000);
tic;rcond(a);toc
