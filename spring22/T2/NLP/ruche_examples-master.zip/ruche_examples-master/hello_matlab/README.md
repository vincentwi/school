# Sample matlab job

Submit the code to the scheduler.

```shell 
sbatch slurm.sh
```
