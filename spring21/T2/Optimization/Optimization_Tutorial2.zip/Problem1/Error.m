function Err = Error(Theta, time, output)
a1 = 0.4;
a2 = 0.1;
a3 = 2  ;

T1 = Theta(1);
T2 = Theta(2);
T3 = Theta(3);

Err=; % TO BE COMPLETED
 
