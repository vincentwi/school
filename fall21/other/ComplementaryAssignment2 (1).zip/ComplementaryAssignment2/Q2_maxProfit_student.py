#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 14 21:50:51 2021

@author: bing
"""
def maxProfit(plist, amount):
    pass


if __name__ == "__main__":
    plist = [[0, 13, 16, 17, 19], 
             [0, 12, 14, 16, 18],
             [0, 18, 19, 20, 20]]
    
    amount = 4
    print(maxProfit(plist, amount))