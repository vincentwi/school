#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 26 21:52:06 2021

@author: bing
"""

def slope(x1, y1, x2, y2):
    pass


def intercept(x1, y1, x2, y2):
    pass


##Testing of your code
if __name__ == "__main__":
    print(slope(1, 1, 2, 2))
    print(intercept(1, 1, 2, 2))
    print(slope(0, 0, 4, 3))
    print(intercept(0, 0, 4, 3))
    print(slope(0, 0, 0, 3))
    print(intercept(0, 0, 0, 3))
    
    